<?php
require('header.php');
?>
<p><b>Error!&nbsp;</b>
Wrong page! Go to the&nbsp;<a href="/index.php/list">main page</a>.</p>

<?php
require('footer.php');
?>